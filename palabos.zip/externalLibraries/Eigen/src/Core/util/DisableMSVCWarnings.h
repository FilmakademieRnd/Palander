
#ifdef _MSC_VER
  #pragma warning( push )
  #pragma warning( disable : 4181 4244 4127 4211 4717 )
#endif
